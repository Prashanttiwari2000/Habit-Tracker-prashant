export const userSelector = (state) => state.userReducer.userUID;

export const habitsSelector = (state) => state.habitsReducer.habits;